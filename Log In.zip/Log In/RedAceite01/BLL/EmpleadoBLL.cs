﻿using DAO.Repositorio;
using Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class EmpleadoBLL
    { 
        private readonly IEmpleadoRepository _empleadoRepository;

        // Constructor que acepta un IEmpleadoRepository
        public EmpleadoBLL(IEmpleadoRepository empleadoRepository)
        {
            _empleadoRepository = empleadoRepository;
        }

        public bool VerificarCredenciales(string nombreUsuario, string contraseña)
        {
            var empleado = _empleadoRepository.ObtenerPorCredenciales(nombreUsuario, contraseña);
            return empleado != null;
        }

        public Empleado ObtenerDetallesEmpleado(string nombreUsuario, string contraseña)
        {
            return _empleadoRepository.ObtenerPorCredenciales(nombreUsuario, contraseña);
        }
        
    }
}
