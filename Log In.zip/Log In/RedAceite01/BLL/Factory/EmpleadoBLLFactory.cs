﻿using DAO.Repositorio;
using DAO.Singleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO.Repositorio;

namespace BLL.Factory
{
    public class EmpleadoBLLFactory:IEmpleadoBLLFactory
    {
        public EmpleadoBLL CrearEmpleadoBLL()
        {
            // Crear una instancia del repositorio usando la conexión singleton
            IEmpleadoRepository empleadoRepository = new EmpleadoRepository(DatabaseConnectionSingleton.Instance.ConnectionString);
            return new EmpleadoBLL(empleadoRepository);
        }

    }
}
