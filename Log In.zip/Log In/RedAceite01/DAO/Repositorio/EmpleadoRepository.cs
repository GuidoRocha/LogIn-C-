﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO.Repositorio
{
    public class EmpleadoRepository : IEmpleadoRepository
    {
        private readonly string connectionString;

        public EmpleadoRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public Empleado ObtenerPorCredenciales(string nombreUsuario, string contraseña)
        {
            Empleado empleado = null;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT u.*, r.idRol
                                 FROM Usuario u
                                 JOIN Empleado e ON u.idEmpleado = e.idEmpleado
                                 JOIN EmpleadoRol r ON e.idEmpleado = r.idEmpleado
                                 WHERE u.nombreUsuario = @nombreUsuario AND u.contraseña = @contraseña;";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@nombreUsuario", nombreUsuario);
                command.Parameters.AddWithValue("@contraseña", contraseña);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    empleado = new Empleado
                    {
                        IdEmpleado = (int)reader["idEmpleado"],
                        IdRol = (int)reader["idRol"],
                        NombreUsuario = reader["nombreUsuario"].ToString(),
                        Contraseña = reader["contraseña"].ToString(),
                        FechaCreacion = (DateTime)reader["fechaCreacion"]
                    };
                }
            }
            return empleado;
        }
    }
}
