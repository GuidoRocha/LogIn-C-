﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO.Singleton
{
    public class DatabaseConnectionSingleton
    {
        private static DatabaseConnectionSingleton _instance;
        private static readonly object _lock = new object();

        public string ConnectionString { get; private set; }

        private DatabaseConnectionSingleton()
        {
            // Verifica que este nombre coincida con el del App.config
            ConnectionString = ConfigurationManager.ConnectionStrings["ConexionEmpleados"]?.ConnectionString;

            if (ConnectionString == null)
            {
                throw new InvalidOperationException("No se pudo encontrar la cadena de conexión especificada.");
            }
        }

        public static DatabaseConnectionSingleton Instance
        {
            get
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new DatabaseConnectionSingleton();
                    }
                    return _instance;
                }
            }
        }
    }
}
